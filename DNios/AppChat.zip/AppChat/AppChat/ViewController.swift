//
//  ViewController.swift
//  AppChat
//
//  Created by local192 on 01/02/2021.
//

import UIKit
import FirebaseAuth
import Firebase

class ViewController: UIViewController {
    
    @IBOutlet weak var textChat: UITextField!
    var ref: DatabaseReference!
    var username: String?
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        loginAnonymous()
        ref = Database.database().reference()
    }
    
    func loginAnonymous(){
        Auth.auth().signInAnonymously { (authResult, error) in
            if let error = error {
                print("probleme with loginAnonimous \(error)")
            }else{
                print("log with uid \(String(describing: authResult?.user.uid))")
            }
        }
    }
    
    @IBAction func buttonActionSend(_ sender: Any) {
        let dict = [
            "userName": username ?? "default",
            "text": textChat.text ?? "default",
            "postDate": ServerValue.timestamp()
    
        ] as [String: Any]
        
        self.ref.child("chat").childByAutoId().setValue(dict)
    }
}

