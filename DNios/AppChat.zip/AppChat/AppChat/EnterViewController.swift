//
//  ChatRoomViewController.swift
//  AppChat
//
//  Created by local192 on 02/02/2021.
//

import UIKit

class EnterViewController: UIViewController {

    @IBOutlet weak var textUserName: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func buttonActionName(_ sender: Any) {
        performSegue(withIdentifier: "chatRoom", sender: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "chatRoom" {
            if let destination = segue.destination as? ViewController {
                destination.username = textUserName.text
            }
        }
    }

}
