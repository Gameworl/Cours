package iut.lp.dba.contactresolver;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    private String URL = "content://iut.lp.dba.contactprovider/contacts";
    private Uri contacts = Uri.parse(URL);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void Add_btn(View view) {
        ContentValues values = new ContentValues();
        values.put("name","Natan Charpentier");
        values.put("phone_number","0695027213");
        values.put("email", "test@gmail.com");

        Uri uri = getContentResolver().insert(contacts, values);
        Toast.makeText(getBaseContext(), "Contact resolver app :"+ uri.toString() + " inserted", Toast.LENGTH_LONG).show();
    }

    public void show_btn(View view){

        Cursor c = getContentResolver().query(contacts,null,null,null, "name");
        String result = "Contact resolver app";
        if (!c.moveToFirst()){
            Toast.makeText(this,  result + "not inserted  yet", Toast.LENGTH_LONG).show();
        }else {
            do {
                result = result + "\n"+ "id : " + c.getString(c.getColumnIndex("id")) +  "\n"+
                        "name : " + c.getString(c.getColumnIndex("name")) +  "\n"+
                        "phone : " + c.getString(c.getColumnIndex("phone_number")) +  "\n"+
                        "email : " + c.getString(c.getColumnIndex("email")) +  "\n";
            }while (c.moveToNext());

                 Toast.makeText(this,  result , Toast.LENGTH_LONG).show();
        }

    }
}