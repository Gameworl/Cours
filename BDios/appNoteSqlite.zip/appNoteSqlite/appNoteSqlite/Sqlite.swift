//
//  Sqlite.swift
//  appNoteSqlite
//
//  Created by local192 on 05/01/2021.
//

import Foundation
import SQLite3

class Sqlite{
/*
* A wrapper around an opaque C pointer
* see https://developer.apple.com/documentation/swift/opaquepointer
*/

var dbPtr: OpaquePointer? = nil
let sqlitePath: String

    
init?(path: String){
    sqlitePath = path
    dbPtr = self.openDatabase(path: sqlitePath)
}
    
    func openDatabase(path: String) -> OpaquePointer {
        var connectdb: OpaquePointer? = nil
        var dbStatus : Int32 = SQLITE_ERROR
        
        dbStatus = sqlite3_open(path, &connectdb)
        
        if dbStatus != SQLITE_OK {
            print("unable to open dataBase. Error: ", dbStatus)
        }
        return connectdb!
    }
    
    
    func createTable(_ tableName: String, columnInfo: [String]) -> Int32 {
        var dbStatus: Int32 = SQLITE_ERROR
        let sqlCmd: String = "create table if not exists \(tableName) " + "(\(columnInfo.joined(separator: ",")))"
        dbStatus = sqlite3_exec(dbPtr, String(sqlCmd), nil, nil, nil)
        
        if dbStatus == SQLITE_OK {
            print("table create ")
        }
        return dbStatus
    }
    
    func insert(_ tableName: String, rowInfo: [String: String]) -> Int32 {
            var dbStatus: Int32 = SQLITE_ERROR
            
            let sqlCmd: String = "insert into \(tableName) "
                + "(\(rowInfo.keys.joined(separator: ",")))"
                + "values (\(rowInfo.values.joined(separator: ",")))"
            
            dbStatus = sqlite3_exec(self.dbPtr, String(sqlCmd), nil, nil, nil)
            
            return dbStatus
        }
    
    let rowCount = 15
    func fetch(_ tableName: String, cond: String?, sortBy order: String?, offset: Int?) -> OpaquePointer {
        var dbStatus: Int32 = SQLITE_ERROR
        
        var sqlCmd: String = "select * from \(tableName)"
        if let condition = cond {
            sqlCmd += " where \(condition)"
        }
        if let orderBy = order {
            sqlCmd += " order by \(orderBy)"
        }
        sqlCmd += " limit \(rowCount)"
        if let offsetNum = offset {
            sqlCmd += " offset \(offsetNum)"
        }
        
        var statement: OpaquePointer? = nil
        dbStatus = sqlite3_prepare_v2(self.dbPtr, String(sqlCmd),-1,&statement, nil)
        
        return statement!
    }
    
}
