//
//  ViewController.swift
//  appNoteSqlite
//
//  Created by local192 on 05/01/2021.
//

import UIKit
import SQLite3

class ViewController: UIViewController {

    let dbTableName: String = "myNotes"
    var db: Sqlite?
    
    override func viewDidLoad(){
        super.viewDidLoad()
        do {
            let documentDirectory = try FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
            let dbFileUrl = documentDirectory.appendingPathComponent("myNotes").appendingPathExtension("sqlite3")
            print(dbFileUrl.path)
            db = Sqlite(path: dbFileUrl.absoluteString)
        }catch{
            print("error")
        }
    }

    @IBAction func createTable(_ sender: Any) {
        if db != nil {
                    let dbStatus = db!.createTable(dbTableName, columnInfo: [
                        "id integer primary key autoincrement",
                        "title text",
                        "desc text",
                        "date_creation date"
                    ])
                    if dbStatus == SQLITE_OK {
                        print("Note Table is created")
                    }else{
                        print("Note Table is NOT created")
                    }
                }
    }
    
    
    @IBAction func InsertNote(_ sender: Any) {
        let alert = UIAlertController(title: "Insert Note", message: nil, preferredStyle: .alert)
                
                alert.addTextField { (tf) in tf.placeholder = "Title" }
                alert.addTextField { (tf) in tf.placeholder = "Descrption" }
                
                let action = UIAlertAction(title: "Save", style: .default) {
                    (action) in
                    guard let noteTitle = alert.textFields?.first?.text,
                        let noteDesc = alert.textFields?.last?.text
                        else {return}
    
                    if self.db != nil {
                        let noteDateCreation = NSDate() as Date
                        let dbStatus = self.db!.insert("'\(self.dbTableName)'",
                            rowInfo: ["title":"'\(noteTitle)'",
                                "desc":"'\(noteDesc)'",
                                "date_creation":"'\(noteDateCreation)'"])
                        
                        if dbStatus == SQLITE_OK {
                            print("A new note is inserted")
                        } else {
                            print("Failed : insert note")
                        }
                    }
                } //fin du callback
        alert.addAction(action)
        present(alert, animated: true, completion: nil)
    }
    
    
    
    @IBAction func listNote(_ sender: Any) {
        let statement = db!.fetch(self.dbTableName, cond: nil, sortBy: nil, offset: nil)
                
                while sqlite3_step(statement) == SQLITE_ROW {
                    let noteId = sqlite3_column_int(statement, 0)
                    let noteTitle = String(cString: sqlite3_column_text(statement, 1))
                    let noteDesc = String(cString: sqlite3_column_text(statement, 2))
                    let noteDateCreation = String(cString: sqlite3_column_text(statement, 3))
                    
                    print("""
                    --------------------
                    noteId : \(noteId),
                    title : \(noteTitle),
                    desc: \(noteDesc),
                    date: \(noteDateCreation)
                    --------------------
                    """)
                }
    }
    
}

